`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module: cpr_uart_btn_top
// Target: Xilinx Artix-7 XC7A35T-1CSG324C (EGO1 Development Board)
// Clock : 100 MHz (P17)
// UART  : 115200 baud, 8-N-1 (TX -> T4)
// Function:
//   使用 EGO1 板載按鍵 S0~S4 模擬鍵盤 ASCII 透過 UART 傳送至電腦/網頁：
//     S0 (R11) -> 0x20 (Space) : 標準按壓
//     S1 (R17) -> 0x53 ('S')   : 過淺按壓
//     S2 (R15) -> 0x45 ('E')   : 未回彈
//     S3 (V1)  -> 0x56 ('V')   : 切換顯示模式
//     S4 (U4)  -> 0x50 ('P')   : 暫停 / 繼續 (或依原版 Web Serial 觸發)
//////////////////////////////////////////////////////////////////////////////////

module cpr_uart_btn_top #(
    parameter integer CLK_FREQ = 100_000_000,
    parameter integer BAUD_RATE = 115200
)(
    input  wire       clk,      // 100MHz 系統時脈 (P17)
    input  wire       rst_n,    // 低電位重置按鈕 (P15)
    input  wire [4:0] btn_s,    // S0~S4 按鍵 (高電位有效)
    output wire       uart_tx,  // USB-UART TX (T4)
    output wire [4:0] led       // LD0~LD4 對應 S0~S4 狀態指示燈
);

    // ---------------------------------------------------------
    // 1. 20ms 硬體去彈跳 + 上升緣偵測 (S0 ~ S4)
    // ---------------------------------------------------------
    wire [4:0] btn_stable;
    wire [4:0] btn_pulse;

    genvar i;
    generate
        for (i = 0; i < 5; i = i + 1) begin : gen_debounce
            btn_debounce #(
                .CLK_FREQ(CLK_FREQ),
                .DEBOUNCE_MS(20)
            ) u_db (
                .clk        (clk),
                .rst_n      (rst_n),
                .btn_in     (btn_s[i]),
                .btn_stable (btn_stable[i]),
                .btn_posedge(btn_pulse[i])
            );
        end
    endgenerate

    // LED 直接顯示目前按下的按鍵狀態
    assign led = btn_stable;

    // ---------------------------------------------------------
    // 2. 按鍵對應鍵盤 ASCII 編碼並觸發 UART 傳送
    // ---------------------------------------------------------
    reg        tx_start;
    reg  [7:0] tx_data;
    wire       tx_busy;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx_start <= 1'b0;
            tx_data  <= 8'h00;
        end else begin
            tx_start <= 1'b0;
            if (!tx_busy) begin
                if (btn_pulse[0]) begin
                    tx_data  <= 8'h20; // S0 -> Space (標準按壓)
                    tx_start <= 1'b1;
                end else if (btn_pulse[1]) begin
                    tx_data  <= 8'h53; // S1 -> 'S'   (過淺按壓)
                    tx_start <= 1'b1;
                end else if (btn_pulse[2]) begin
                    tx_data  <= 8'h45; // S2 -> 'E'   (未回彈)
                    tx_start <= 1'b1;
                end else if (btn_pulse[3]) begin
                    tx_data  <= 8'h56; // S3 -> 'V'   (切換顯示模式)
                    tx_start <= 1'b1;
                end else if (btn_pulse[4]) begin
                    tx_data  <= 8'h50; // S4 -> 'P'   (暫停/繼續)
                    tx_start <= 1'b1;
                end
            end
        end
    end

    // ---------------------------------------------------------
    // 3. UART 115200 8-N-1 傳送模組
    // ---------------------------------------------------------
    uart_tx_module #(
        .CLK_FREQ (CLK_FREQ),
        .BAUD_RATE(BAUD_RATE)
    ) u_uart_tx (
        .clk     (clk),
        .rst_n   (rst_n),
        .tx_start(tx_start),
        .tx_data (tx_data),
        .tx_pin  (uart_tx),
        .tx_busy (tx_busy)
    );

endmodule


//////////////////////////////////////////////////////////////////////////////////
// Submodule: btn_debounce (20ms 去彈跳 + 單週期上升緣脈波)
//////////////////////////////////////////////////////////////////////////////////
module btn_debounce #(
    parameter integer CLK_FREQ    = 100_000_000,
    parameter integer DEBOUNCE_MS = 20
)(
    input  wire clk,
    input  wire rst_n,
    input  wire btn_in,
    output reg  btn_stable,
    output reg  btn_posedge
);
    localparam integer CNT_MAX = (CLK_FREQ / 1000) * DEBOUNCE_MS;

    reg [1:0]  sync_ff;
    reg [21:0] cnt;
    reg        btn_prev;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sync_ff     <= 2'b00;
            cnt         <= 22'd0;
            btn_stable  <= 1'b0;
            btn_prev    <= 1'b0;
            btn_posedge <= 1'b0;
        end else begin
            sync_ff <= {sync_ff[0], btn_in};
            btn_prev <= btn_stable;
            btn_posedge <= 1'b0;

            if (sync_ff[1] != btn_stable) begin
                if (cnt >= CNT_MAX - 1) begin
                    btn_stable <= sync_ff[1];
                    cnt        <= 22'd0;
                end else begin
                    cnt <= cnt + 22'd1;
                end
            end else begin
                cnt <= 22'd0;
            end

            if (btn_stable && !btn_prev) begin
                btn_posedge <= 1'b1;
            end
        end
    end
endmodule


//////////////////////////////////////////////////////////////////////////////////
// Submodule: uart_tx_module (115200 baud, 8-N-1)
//////////////////////////////////////////////////////////////////////////////////
module uart_tx_module #(
    parameter integer CLK_FREQ  = 100_000_000,
    parameter integer BAUD_RATE = 115200
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       tx_start,
    input  wire [7:0] tx_data,
    output reg        tx_pin,
    output reg        tx_busy
);
    localparam integer BAUD_DIV = CLK_FREQ / BAUD_RATE; // 100M / 115200 = 868

    reg [15:0] baud_cnt;
    reg [3:0]  bit_idx;
    reg [9:0]  shift_reg; // {Stop(1), Data[7:0], Start(0)}

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx_pin    <= 1'b1; // Idle High
            tx_busy   <= 1'b0;
            baud_cnt  <= 16'd0;
            bit_idx   <= 4'd0;
            shift_reg <= 10'h3FF;
        end else begin
            if (!tx_busy) begin
                tx_pin <= 1'b1;
                if (tx_start) begin
                    shift_reg <= {1'b1, tx_data, 1'b0};
                    tx_busy   <= 1'b1;
                    baud_cnt  <= 16'd0;
                    bit_idx   <= 4'd0;
                end
            end else begin
                tx_pin <= shift_reg[0];
                if (baud_cnt >= BAUD_DIV - 1) begin
                    baud_cnt <= 16'd0;
                    if (bit_idx == 4'd9) begin
                        tx_busy <= 1'b0;
                        tx_pin  <= 1'b1;
                    end else begin
                        bit_idx   <= bit_idx + 4'd1;
                        shift_reg <= {1'b1, shift_reg[9:1]};
                    end
                end else begin
                    baud_cnt <= baud_cnt + 16'd1;
                end
            end
        end
    end
endmodule
