## =============================================================================
## EGO1 (Xilinx Artix-7 XC7A35T-1CSG324C) Pin Constraints
## Project: CPR Rhythm Training System - UART ASCII Controller (S0~S4)
## =============================================================================

## 100 MHz System Clock
set_property -dict { PACKAGE_PIN P17   IOSTANDARD LVCMOS33 } [get_ports { clk }]
create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports { clk }]

## Reset Button (Active-Low on EGO1)
set_property -dict { PACKAGE_PIN P15   IOSTANDARD LVCMOS33 } [get_ports { rst_n }]

## Push Buttons S0 ~ S4 (Active-High on EGO1)
set_property -dict { PACKAGE_PIN R11   IOSTANDARD LVCMOS33 } [get_ports { btn_s[0] }] ; # S0 -> Space (0x20)
set_property -dict { PACKAGE_PIN R17   IOSTANDARD LVCMOS33 } [get_ports { btn_s[1] }] ; # S1 -> 'S'   (0x53)
set_property -dict { PACKAGE_PIN R15   IOSTANDARD LVCMOS33 } [get_ports { btn_s[2] }] ; # S2 -> 'E'   (0x45)
set_property -dict { PACKAGE_PIN V1    IOSTANDARD LVCMOS33 } [get_ports { btn_s[3] }] ; # S3 -> 'V'   (0x56)
set_property -dict { PACKAGE_PIN U4    IOSTANDARD LVCMOS33 } [get_ports { btn_s[4] }] ; # S4 -> 'P'   (0x50)

## USB-UART TX (FPGA TX -> PC RX)
set_property -dict { PACKAGE_PIN T4    IOSTANDARD LVCMOS33 } [get_ports { uart_tx }]

## On-board LEDs LD0 ~ LD4 (對應 S0 ~ S4 按下指示)
set_property -dict { PACKAGE_PIN K2    IOSTANDARD LVCMOS33 } [get_ports { led[0] }]
set_property -dict { PACKAGE_PIN J2    IOSTANDARD LVCMOS33 } [get_ports { led[1] }]
set_property -dict { PACKAGE_PIN J3    IOSTANDARD LVCMOS33 } [get_ports { led[2] }]
set_property -dict { PACKAGE_PIN H4    IOSTANDARD LVCMOS33 } [get_ports { led[3] }]
set_property -dict { PACKAGE_PIN J4    IOSTANDARD LVCMOS33 } [get_ports { led[4] }]
