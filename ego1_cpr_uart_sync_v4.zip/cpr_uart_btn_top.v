`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module: cpr_uart_btn_top
// Target: Xilinx Artix-7 XC7A35T-1CSG324C (EGO1 Development Board)
// Clock : 100 MHz (P17)
// UART  : 115200 baud, 8-N-1 (TX -> T4, RX -> N5)
// Features:
//   支援「單機離線模式」與「網頁連線同步模式」自動切換：
//   1. 未連網頁（單機模式, web_online = 0）：
//        - 按住 S0 (標準按壓)：16 顆 LED (LD2+LD1) 平滑上升至滿格 (16 顆)，放開平滑回彈歸零；
//                              左側 DN0 (總次數) +1，右側 DN1 (標準/Perfect 次數) +1。
//        - 按住 S1 (過淺按壓)：16 顆 LED 平滑上升至半格 (8 顆)，放開歸零；左側 DN0 +1。
//        - 按住 S2 (未回彈)  ：16 顆 LED 平滑上升至 12 顆，放開歸零；左側 DN0 +1。
//        - 按下 rst_n (P15)  ：重置所有計數器並切回單機模式。
//   2. 已連網頁（連線同步模式, web_online = 1，收到網頁 UART 指令後自動切換）：
//        - FPGA -> PC (TX, T4)：S0=Space, S1='S', S2='E', S3='V', S4='P'
//        - PC -> FPGA (RX, N5)：
//            0x80 ~ 0x90 : 即時同步網頁右上 12-LED 霹靂燈至板載 16 顆 LED (LD2+LD1)
//            0x2B ('+')  : 網頁判定 PERFECT / GOOD 時，右側 DN1 +1
//            0x52 ('R')  : 網頁開始／重啟遊戲時，左右兩組計數器 (DN0, DN1) 與 LED 同步歸零
//////////////////////////////////////////////////////////////////////////////////

module cpr_uart_btn_top #(
    parameter integer CLK_FREQ  = 100_000_000,
    parameter integer BAUD_RATE = 115200
)(
    input  wire        clk,       // 100MHz 系統時脈 (P17)
    input  wire        rst_n,     // 低電位重置按鈕 (P15)
    input  wire [4:0]  btn_s,     // S0~S4 按鍵 (高電位有效)
    input  wire        uart_rx,   // USB-UART RX (N5, 接收網頁回饋)
    output wire        uart_tx,   // USB-UART TX (T4, 傳送按鍵 ASCII)
    output reg  [15:0] led_bar,   // 16 顆 LED: [15:8]=LD2[7:0], [7:0]=LD1[7:0] (由左至右)
    output wire [3:0]  seg0_an,   // 左側 4 位數七段位選 DN0 (G2, C2, C1, H1)
    output wire [7:0]  seg0_out,  // 左側 4 位數七段段選 {dp,g,f,e,d,c,b,a}
    output wire [3:0]  seg1_an,   // 右側 4 位數七段位選 DN1 (G1, F1, E1, G6)
    output wire [7:0]  seg1_out   // 右側 4 位數七段段選 {dp,g,f,e,d,c,b,a}
);

    // ---------------------------------------------------------
    // 1. 20ms 硬體去彈跳 + 上升緣偵測 (S0 ~ S4)
    // ---------------------------------------------------------
    wire [4:0] btn_stable;
    wire [4:0] btn_pulse;

    genvar i;
    generate
        for (i = 0; i < 5; i = i + 1) begin : gen_debounce
            btn_debounce #(
                .CLK_FREQ(CLK_FREQ),
                .DEBOUNCE_MS(20)
            ) u_db (
                .clk        (clk),
                .rst_n      (rst_n),
                .btn_in     (btn_s[i]),
                .btn_stable (btn_stable[i]),
                .btn_posedge(btn_pulse[i])
            );
        end
    endgenerate

    // ---------------------------------------------------------
    // 2. 按鍵對應鍵盤 ASCII 編碼並觸發 UART 傳送
    // ---------------------------------------------------------
    reg        tx_start;
    reg  [7:0] tx_data;
    wire       tx_busy;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx_start <= 1'b0;
            tx_data  <= 8'h00;
        end else begin
            tx_start <= 1'b0;
            if (!tx_busy) begin
                if (btn_pulse[0]) begin
                    tx_data  <= 8'h20; // S0 -> Space (標準按壓)
                    tx_start <= 1'b1;
                end else if (btn_pulse[1]) begin
                    tx_data  <= 8'h53; // S1 -> 'S'   (過淺按壓)
                    tx_start <= 1'b1;
                end else if (btn_pulse[2]) begin
                    tx_data  <= 8'h45; // S2 -> 'E'   (未回彈)
                    tx_start <= 1'b1;
                end else if (btn_pulse[3]) begin
                    tx_data  <= 8'h56; // S3 -> 'V'   (切換顯示模式)
                    tx_start <= 1'b1;
                end else if (btn_pulse[4]) begin
                    tx_data  <= 8'h50; // S4 -> 'P'   (暫停/繼續)
                    tx_start <= 1'b1;
                end
            end
        end
    end

    // ---------------------------------------------------------
    // 3. UART 115200 8-N-1 傳送與接收模組
    // ---------------------------------------------------------
    uart_tx_module #(
        .CLK_FREQ (CLK_FREQ),
        .BAUD_RATE(BAUD_RATE)
    ) u_uart_tx (
        .clk     (clk),
        .rst_n   (rst_n),
        .tx_start(tx_start),
        .tx_data (tx_data),
        .tx_pin  (uart_tx),
        .tx_busy (tx_busy)
    );

    wire [7:0] rx_data;
    wire       rx_valid;

    uart_rx_module #(
        .CLK_FREQ (CLK_FREQ),
        .BAUD_RATE(BAUD_RATE)
    ) u_uart_rx (
        .clk     (clk),
        .rst_n   (rst_n),
        .rx_pin  (uart_rx),
        .rx_data (rx_data),
        .rx_valid(rx_valid)
    );

    // ---------------------------------------------------------
    // 4. 解析網頁 UART RX 指令 & 自動偵測是否已連網頁 (web_online)
    // ---------------------------------------------------------
    reg       web_online;
    reg [4:0] web_led_level;  // 網頁同步 LED 長度 (0 ~ 16)
    reg       web_pg_inc;
    reg       web_clr;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            web_online    <= 1'b0;
            web_led_level <= 5'd0;
            web_pg_inc    <= 1'b0;
            web_clr       <= 1'b0;
        end else begin
            web_pg_inc <= 1'b0;
            web_clr    <= 1'b0;
            if (rx_valid) begin
                if (rx_data >= 8'h80 && rx_data <= 8'h90) begin
                    web_online    <= 1'b1;
                    web_led_level <= rx_data[4:0];
                end else if (rx_data == 8'h2B) begin // '+'
                    web_online <= 1'b1;
                    web_pg_inc <= 1'b1;
                end else if (rx_data == 8'h52) begin // 'R' (遊戲開始/重啟)
                    web_online    <= 1'b1;
                    web_clr       <= 1'b1;
                    web_led_level <= 5'd0;
                end
            end
        end
    end

    // ---------------------------------------------------------
    // 5. 單機離線模式 LED 平滑霹靂燈控制 (約每 15ms 變化 1 格)
    //    - 按住 S0 -> 目標 16 顆 (滿深度)
    //    - 按住 S1 -> 目標 8 顆  (過淺)
    //    - 按住 S2 -> 目標 12 顆 (未回彈)
    //    - 放開    -> 目標 0 顆  (平滑回彈)
    // ---------------------------------------------------------
    localparam integer RAMP_DIV = CLK_FREQ / 65; // 約 15.4 ms 步進一次

    reg [21:0] ramp_cnt;
    reg [4:0]  local_led_level;
    reg [4:0]  local_target;

    always @(*) begin
        if (btn_stable[0])      local_target = 5'd16;
        else if (btn_stable[2]) local_target = 5'd12;
        else if (btn_stable[1]) local_target = 5'd8;
        else                    local_target = 5'd0;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ramp_cnt        <= 22'd0;
            local_led_level <= 5'd0;
        end else begin
            if (ramp_cnt >= RAMP_DIV - 1) begin
                ramp_cnt <= 22'd0;
                if (local_led_level < local_target)
                    local_led_level <= local_led_level + 5'd1;
                else if (local_led_level > local_target)
                    local_led_level <= local_led_level - 5'd1;
            end else begin
                ramp_cnt <= ramp_cnt + 22'd1;
            end
        end
    end

    // 依是否連線自動選擇 LED 來源
    wire [4:0] active_led_level = web_online ? web_led_level : local_led_level;

    // 將 active_led_level (0~16) 轉換為由左至右點亮的 16 顆 LED (LD2[7] -> LD1[0])
    integer k;
    always @(*) begin
        for (k = 0; k < 16; k = k + 1) begin
            led_bar[15 - k] = (k < active_led_level) ? 1'b1 : 1'b0;
        end
    end

    // ---------------------------------------------------------
    // 6. 雙四位數七段顯示器：
    //    - 左側 DN0: 按壓總次數 (S0 / S1 / S2)，遊戲重啟 ('R') 或 rst_n 歸零
    //    - 右側 DN1:
    //        * 連線模式：網頁 Perfect + Good 次數 ('+' 加 1, 'R' 歸零)
    //        * 單機模式：S0 標準按壓次數 (btn_pulse[0] 加 1, rst_n 歸零)
    // ---------------------------------------------------------
    wire press_inc  = btn_pulse[0] | btn_pulse[1] | btn_pulse[2];
    wire seg1_inc   = web_online ? web_pg_inc : btn_pulse[0];

    seg7_counter_display u_seg0_total (
        .clk     (clk),
        .rst_n   (rst_n),
        .clr     (web_clr),
        .inc_en  (press_inc),
        .seg_an  (seg0_an),
        .seg_out (seg0_out)
    );

    seg7_counter_display u_seg1_pg (
        .clk     (clk),
        .rst_n   (rst_n),
        .clr     (web_clr),
        .inc_en  (seg1_inc),
        .seg_an  (seg1_an),
        .seg_out (seg1_out)
    );

endmodule


//////////////////////////////////////////////////////////////////////////////////
// Submodule: seg7_counter_display (4 位數 BCD 計數器 0000~9999 + 動態掃描)
//////////////////////////////////////////////////////////////////////////////////
module seg7_counter_display (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       clr,
    input  wire       inc_en,
    output reg  [3:0] seg_an,
    output reg  [7:0] seg_out // {dp, g, f, e, d, c, b, a}
);
    reg [3:0] d0, d1, d2, d3; // 個、十、百、千位

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            d0 <= 4'd0; d1 <= 4'd0; d2 <= 4'd0; d3 <= 4'd0;
        end else if (clr) begin
            d0 <= 4'd0; d1 <= 4'd0; d2 <= 4'd0; d3 <= 4'd0;
        end else if (inc_en) begin
            if (d0 == 4'd9) begin
                d0 <= 4'd0;
                if (d1 == 4'd9) begin
                    d1 <= 4'd0;
                    if (d2 == 4'd9) begin
                        d2 <= 4'd0;
                        if (d3 == 4'd9) d3 <= 4'd0;
                        else            d3 <= d3 + 4'd1;
                    end else begin
                        d2 <= d2 + 4'd1;
                    end
                end else begin
                    d1 <= d1 + 4'd1;
                end
            end else begin
                d0 <= d0 + 4'd1;
            end
        end
    end

    reg [18:0] scan_cnt;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) scan_cnt <= 19'd0;
        else        scan_cnt <= scan_cnt + 19'd1;
    end

    wire [1:0] digit_sel = scan_cnt[18:17];
    reg  [3:0] cur_digit;

    always @(*) begin
        case (digit_sel)
            2'd0: begin seg_an = 4'b0001; cur_digit = d0; end // 個位
            2'd1: begin seg_an = 4'b0010; cur_digit = d1; end // 十位
            2'd2: begin seg_an = 4'b0100; cur_digit = d2; end // 百位
            2'd3: begin seg_an = 4'b1000; cur_digit = d3; end // 千位
            default: begin seg_an = 4'b0000; cur_digit = 4'd0; end
        endcase
    end

    always @(*) begin
        case (cur_digit)
            4'd0: seg_out = 8'b0011_1111; // 0
            4'd1: seg_out = 8'b0000_0110; // 1
            4'd2: seg_out = 8'b0101_1011; // 2
            4'd3: seg_out = 8'b0100_1111; // 3
            4'd4: seg_out = 8'b0110_0110; // 4
            4'd5: seg_out = 8'b0110_1101; // 5
            4'd6: seg_out = 8'b0111_1101; // 6
            4'd7: seg_out = 8'b0000_0111; // 7
            4'd8: seg_out = 8'b0111_1111; // 8
            4'd9: seg_out = 8'b0110_1111; // 9
            default: seg_out = 8'b0000_0000;
        endcase
    end
endmodule


//////////////////////////////////////////////////////////////////////////////////
// Submodule: btn_debounce (20ms 去彈跳 + 單週期上升緣脈波)
//////////////////////////////////////////////////////////////////////////////////
module btn_debounce #(
    parameter integer CLK_FREQ    = 100_000_000,
    parameter integer DEBOUNCE_MS = 20
)(
    input  wire clk,
    input  wire rst_n,
    input  wire btn_in,
    output reg  btn_stable,
    output reg  btn_posedge
);
    localparam integer CNT_MAX = (CLK_FREQ / 1000) * DEBOUNCE_MS;

    reg [1:0]  sync_ff;
    reg [21:0] cnt;
    reg        btn_prev;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sync_ff     <= 2'b00;
            cnt         <= 22'd0;
            btn_stable  <= 1'b0;
            btn_prev    <= 1'b0;
            btn_posedge <= 1'b0;
        end else begin
            sync_ff     <= {sync_ff[0], btn_in};
            btn_prev    <= btn_stable;
            btn_posedge <= 1'b0;

            if (sync_ff[1] != btn_stable) begin
                if (cnt >= CNT_MAX - 1) begin
                    btn_stable <= sync_ff[1];
                    cnt        <= 22'd0;
                end else begin
                    cnt <= cnt + 22'd1;
                end
            end else begin
                cnt <= 22'd0;
            end

            if (btn_stable && !btn_prev) begin
                btn_posedge <= 1'b1;
            end
        end
    end
endmodule


//////////////////////////////////////////////////////////////////////////////////
// Submodule: uart_tx_module (115200 baud, 8-N-1)
//////////////////////////////////////////////////////////////////////////////////
module uart_tx_module #(
    parameter integer CLK_FREQ  = 100_000_000,
    parameter integer BAUD_RATE = 115200
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       tx_start,
    input  wire [7:0] tx_data,
    output reg        tx_pin,
    output reg        tx_busy
);
    localparam integer BAUD_DIV = CLK_FREQ / BAUD_RATE; // 868

    reg [15:0] baud_cnt;
    reg [3:0]  bit_idx;
    reg [9:0]  shift_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx_pin    <= 1'b1;
            tx_busy   <= 1'b0;
            baud_cnt  <= 16'd0;
            bit_idx   <= 4'd0;
            shift_reg <= 10'h3FF;
        end else begin
            if (!tx_busy) begin
                tx_pin <= 1'b1;
                if (tx_start) begin
                    shift_reg <= {1'b1, tx_data, 1'b0};
                    tx_busy   <= 1'b1;
                    baud_cnt  <= 16'd0;
                    bit_idx   <= 4'd0;
                end
            end else begin
                tx_pin <= shift_reg[0];
                if (baud_cnt >= BAUD_DIV - 1) begin
                    baud_cnt <= 16'd0;
                    if (bit_idx == 4'd9) begin
                        tx_busy <= 1'b0;
                        tx_pin  <= 1'b1;
                    end else begin
                        bit_idx   <= bit_idx + 4'd1;
                        shift_reg <= {1'b1, shift_reg[9:1]};
                    end
                end else begin
                    baud_cnt <= baud_cnt + 16'd1;
                end
            end
        end
    end
endmodule


//////////////////////////////////////////////////////////////////////////////////
// Submodule: uart_rx_module (115200 baud, 8-N-1, 中點取樣)
//////////////////////////////////////////////////////////////////////////////////
module uart_rx_module #(
    parameter integer CLK_FREQ  = 100_000_000,
    parameter integer BAUD_RATE = 115200
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       rx_pin,
    output reg  [7:0] rx_data,
    output reg        rx_valid
);
    localparam integer BAUD_DIV  = CLK_FREQ / BAUD_RATE; // 868
    localparam integer HALF_BAUD = BAUD_DIV / 2;         // 434

    reg [2:0]  rx_sync;
    reg        rx_busy;
    reg [15:0] baud_cnt;
    reg [3:0]  bit_idx;
    reg [7:0]  shift_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_sync   <= 3'b111;
            rx_busy   <= 1'b0;
            baud_cnt  <= 16'd0;
            bit_idx   <= 4'd0;
            shift_reg <= 8'h00;
            rx_data   <= 8'h00;
            rx_valid  <= 1'b0;
        end else begin
            rx_sync  <= {rx_sync[1:0], rx_pin};
            rx_valid <= 1'b0;

            if (!rx_busy) begin
                if (rx_sync[2] == 1'b1 && rx_sync[1] == 1'b0) begin
                    rx_busy  <= 1'b1;
                    baud_cnt <= 16'd0;
                    bit_idx  <= 4'd0;
                end
            end else begin
                if (bit_idx == 4'd0) begin
                    if (baud_cnt >= HALF_BAUD - 1) begin
                        baud_cnt <= 16'd0;
                        if (rx_sync[1] == 1'b0) bit_idx <= 4'd1;
                        else                    rx_busy <= 1'b0;
                    end else begin
                        baud_cnt <= baud_cnt + 16'd1;
                    end
                end else if (bit_idx <= 4'd8) begin
                    if (baud_cnt >= BAUD_DIV - 1) begin
                        baud_cnt <= 16'd0;
                        shift_reg[bit_idx - 1] <= rx_sync[1];
                        bit_idx <= bit_idx + 4'd1;
                    end else begin
                        baud_cnt <= baud_cnt + 16'd1;
                    end
                end else begin
                    if (baud_cnt >= BAUD_DIV - 1) begin
                        baud_cnt <= 16'd0;
                        rx_busy  <= 1'b0;
                        if (rx_sync[1] == 1'b1) begin
                            rx_data  <= shift_reg;
                            rx_valid <= 1'b1;
                        end
                    end else begin
                        baud_cnt <= baud_cnt + 16'd1;
                    end
                end
            end
        end
    end
endmodule
