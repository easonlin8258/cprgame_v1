## =============================================================================
## EGO1 (Xilinx Artix-7 XC7A35T-1CSG324C) Pin Constraints
## Project: CPR Rhythm Training System - Bidirectional UART + 16-LED Bar + Dual 7-Seg
## =============================================================================

## 100 MHz System Clock
set_property -dict { PACKAGE_PIN P17   IOSTANDARD LVCMOS33 } [get_ports { clk }]
create_clock -add -name sys_clk_pin -period 10.00 -waveform {0 5} [get_ports { clk }]

## Reset Button (Active-Low on EGO1)
set_property -dict { PACKAGE_PIN P15   IOSTANDARD LVCMOS33 } [get_ports { rst_n }]

## Push Buttons S0 ~ S4 (Active-High on EGO1)
set_property -dict { PACKAGE_PIN R11   IOSTANDARD LVCMOS33 } [get_ports { btn_s[0] }] ; # S0 -> Space (0x20)
set_property -dict { PACKAGE_PIN R17   IOSTANDARD LVCMOS33 } [get_ports { btn_s[1] }] ; # S1 -> 'S'   (0x53)
set_property -dict { PACKAGE_PIN R15   IOSTANDARD LVCMOS33 } [get_ports { btn_s[2] }] ; # S2 -> 'E'   (0x45)
set_property -dict { PACKAGE_PIN V1    IOSTANDARD LVCMOS33 } [get_ports { btn_s[3] }] ; # S3 -> 'V'   (0x56)
set_property -dict { PACKAGE_PIN U4    IOSTANDARD LVCMOS33 } [get_ports { btn_s[4] }] ; # S4 -> 'P'   (0x50)

## USB-UART (TX -> PC RX, RX <- PC TX)
set_property -dict { PACKAGE_PIN T4    IOSTANDARD LVCMOS33 } [get_ports { uart_tx }]
set_property -dict { PACKAGE_PIN N5    IOSTANDARD LVCMOS33 } [get_ports { uart_rx }]

## 16-LED Bar (由左至右: LD2[7..0] -> LD1[7..0], 同步網頁右上霹靂燈)
## LD2 (左側 8 顆)
set_property -dict { PACKAGE_PIN F6    IOSTANDARD LVCMOS33 } [get_ports { led_bar[15] }] ; # LD2-7 (最左)
set_property -dict { PACKAGE_PIN G4    IOSTANDARD LVCMOS33 } [get_ports { led_bar[14] }] ; # LD2-6
set_property -dict { PACKAGE_PIN G3    IOSTANDARD LVCMOS33 } [get_ports { led_bar[13] }] ; # LD2-5
set_property -dict { PACKAGE_PIN J4    IOSTANDARD LVCMOS33 } [get_ports { led_bar[12] }] ; # LD2-4
set_property -dict { PACKAGE_PIN H4    IOSTANDARD LVCMOS33 } [get_ports { led_bar[11] }] ; # LD2-3
set_property -dict { PACKAGE_PIN J3    IOSTANDARD LVCMOS33 } [get_ports { led_bar[10] }] ; # LD2-2
set_property -dict { PACKAGE_PIN J2    IOSTANDARD LVCMOS33 } [get_ports { led_bar[9]  }] ; # LD2-1
set_property -dict { PACKAGE_PIN K2    IOSTANDARD LVCMOS33 } [get_ports { led_bar[8]  }] ; # LD2-0
## LD1 (右側 8 顆)
set_property -dict { PACKAGE_PIN K1    IOSTANDARD LVCMOS33 } [get_ports { led_bar[7]  }] ; # LD1-7
set_property -dict { PACKAGE_PIN H6    IOSTANDARD LVCMOS33 } [get_ports { led_bar[6]  }] ; # LD1-6
set_property -dict { PACKAGE_PIN H5    IOSTANDARD LVCMOS33 } [get_ports { led_bar[5]  }] ; # LD1-5
set_property -dict { PACKAGE_PIN J5    IOSTANDARD LVCMOS33 } [get_ports { led_bar[4]  }] ; # LD1-4
set_property -dict { PACKAGE_PIN K6    IOSTANDARD LVCMOS33 } [get_ports { led_bar[3]  }] ; # LD1-3
set_property -dict { PACKAGE_PIN L1    IOSTANDARD LVCMOS33 } [get_ports { led_bar[2]  }] ; # LD1-2
set_property -dict { PACKAGE_PIN M1    IOSTANDARD LVCMOS33 } [get_ports { led_bar[1]  }] ; # LD1-1
set_property -dict { PACKAGE_PIN K3    IOSTANDARD LVCMOS33 } [get_ports { led_bar[0]  }] ; # LD1-0 (最右)

## Left 4-Digit 7-Segment Display DN0 (左側 4 位數：總按壓次數)
set_property -dict { PACKAGE_PIN G2    IOSTANDARD LVCMOS33 } [get_ports { seg0_an[3] }] ; # BIT1 千位
set_property -dict { PACKAGE_PIN C2    IOSTANDARD LVCMOS33 } [get_ports { seg0_an[2] }] ; # BIT2 百位
set_property -dict { PACKAGE_PIN C1    IOSTANDARD LVCMOS33 } [get_ports { seg0_an[1] }] ; # BIT3 十位
set_property -dict { PACKAGE_PIN H1    IOSTANDARD LVCMOS33 } [get_ports { seg0_an[0] }] ; # BIT4 個位

set_property -dict { PACKAGE_PIN B4    IOSTANDARD LVCMOS33 } [get_ports { seg0_out[0] }] ; # CA0
set_property -dict { PACKAGE_PIN A4    IOSTANDARD LVCMOS33 } [get_ports { seg0_out[1] }] ; # CB0
set_property -dict { PACKAGE_PIN A3    IOSTANDARD LVCMOS33 } [get_ports { seg0_out[2] }] ; # CC0
set_property -dict { PACKAGE_PIN B1    IOSTANDARD LVCMOS33 } [get_ports { seg0_out[3] }] ; # CD0
set_property -dict { PACKAGE_PIN A1    IOSTANDARD LVCMOS33 } [get_ports { seg0_out[4] }] ; # CE0
set_property -dict { PACKAGE_PIN B3    IOSTANDARD LVCMOS33 } [get_ports { seg0_out[5] }] ; # CF0
set_property -dict { PACKAGE_PIN B2    IOSTANDARD LVCMOS33 } [get_ports { seg0_out[6] }] ; # CG0
set_property -dict { PACKAGE_PIN D5    IOSTANDARD LVCMOS33 } [get_ports { seg0_out[7] }] ; # DP0

## Right 4-Digit 7-Segment Display DN1 (右側 4 位數：網頁 Perfect + Good 次數)
set_property -dict { PACKAGE_PIN G1    IOSTANDARD LVCMOS33 } [get_ports { seg1_an[3] }] ; # BIT5 千位
set_property -dict { PACKAGE_PIN F1    IOSTANDARD LVCMOS33 } [get_ports { seg1_an[2] }] ; # BIT6 百位
set_property -dict { PACKAGE_PIN E1    IOSTANDARD LVCMOS33 } [get_ports { seg1_an[1] }] ; # BIT7 十位
set_property -dict { PACKAGE_PIN G6    IOSTANDARD LVCMOS33 } [get_ports { seg1_an[0] }] ; # BIT8 個位

set_property -dict { PACKAGE_PIN D4    IOSTANDARD LVCMOS33 } [get_ports { seg1_out[0] }] ; # CA1
set_property -dict { PACKAGE_PIN E3    IOSTANDARD LVCMOS33 } [get_ports { seg1_out[1] }] ; # CB1
set_property -dict { PACKAGE_PIN D3    IOSTANDARD LVCMOS33 } [get_ports { seg1_out[2] }] ; # CC1
set_property -dict { PACKAGE_PIN F4    IOSTANDARD LVCMOS33 } [get_ports { seg1_out[3] }] ; # CD1
set_property -dict { PACKAGE_PIN F3    IOSTANDARD LVCMOS33 } [get_ports { seg1_out[4] }] ; # CE1
set_property -dict { PACKAGE_PIN E2    IOSTANDARD LVCMOS33 } [get_ports { seg1_out[5] }] ; # CF1
set_property -dict { PACKAGE_PIN D2    IOSTANDARD LVCMOS33 } [get_ports { seg1_out[6] }] ; # CG1
set_property -dict { PACKAGE_PIN H2    IOSTANDARD LVCMOS33 } [get_ports { seg1_out[7] }] ; # DP1
